# Core Configuration
